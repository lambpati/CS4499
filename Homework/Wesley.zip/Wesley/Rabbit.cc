#include "Rabbit.hh"

Rabbit::Rabbit(): age(0){}
