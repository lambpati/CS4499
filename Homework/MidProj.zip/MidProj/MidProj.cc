#include "Bunny.hh"
#include "Driver.hh"
#include <iostream>

int main(int argc, char const *argv[]) {
//  Bunny bunny;
//  Driver driver;
//  bunny.setName("bunny");
//  driver.generateGender(bunny);
//  driver.generateColor(bunny);
//  driver.generateRMVB(bunny);

  std::cout << "Bunny generated:" << bunny.getGender() << '\n';
  return 0;
}
